CREATE PROCEDURE incSalary(IN salary1 INT, IN id INT)
  begin
update employee
set salary = salary1
where dept = "Sales" and employee_number = id;
end;
